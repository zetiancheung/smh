./cmd_start  h9-miner-spacemesh-linux-amd64 1 1
